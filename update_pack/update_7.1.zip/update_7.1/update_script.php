<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();

	// define table fields
	$fields = array(
		'id' => array(
			'type' => 'INT',
			'constraint' => 10,
			'unsigned' => TRUE,
			'auto_increment' => TRUE
		),
		'key' => array(
			'type' => 'VARCHAR',
			'constraint' => 200,
			'null' => TRUE
		),
		'value' => array(
			'type' => 'TEXT',
			'null' => TRUE
		)
	);
	$CI->dbforge->add_field($fields);
	// define primary key
	$CI->dbforge->add_key('id', TRUE);
	// create table
	$CI->dbforge->create_table('payment_settings');


	//add column paystack_supported
	$add_currencies_fields = array('paystack_supported' => array('type' => 'int', 'default' => '0'));
	$CI->dbforge->add_column('currencies', $add_currencies_fields);
	//currency supported for paystack
	$currency_supported = array( 'paystack_supported' => '1');
	$CI->db->where('code', 'NGN');
	$CI->db->update('currencies', $currency_supported);

	//add column witch_history
	$add_witch_history_fields = array('watch_history' => array('type' => 'TEXT'));
	$CI->dbforge->add_column('users', $add_witch_history_fields);

	$witch_history_update = array( 'watch_history' => '[]');
	$CI->db->update('users', $witch_history_update);

	//add column payumoney_supported
	$add_currencies_fields_payumoney = array('payumoney_supported' => array('type' => 'int', 'default' => '1'));
	$CI->dbforge->add_column('currencies', $add_currencies_fields_payumoney);

	//add column settings in table
	$add_youtube_api_key = array('youtube_api_key' => array('type' => 'varchar', 'constraint' => 200, 'default' => 'null'));
	$CI->dbforge->add_column('settings', $add_youtube_api_key);

	//add column settings in table
	$add_vimeo_api_key = array('vimeo_api_key' => array('type' => 'varchar', 'constraint' => 200, 'default' => 'null'));
	$CI->dbforge->add_column('settings', $add_vimeo_api_key);

	//insert data in payment_settings table
	$paypal_settings = array( 'key' => 'paypal_settings', 'value' => '[{"paypal_active":"yes","paypal_mode":"sandbox","paypal_client_id_sandbox":"1234","paypal_client_id_production":"1234","paypal_currency":"USD"}]');
	$CI->db->insert('payment_settings', $paypal_settings);

	$stripe_settings = array( 'key' => 'stripe_settings', 'value' => '[{"stripe_active":"yes","stripe_mode":"on","stripe_test_secret_key":"1234","stripe_test_public_key":"1234","stripe_live_secret_key":"1234","stripe_live_public_key":"1234","stripe_currency":"USD"}]');
	$CI->db->insert('payment_settings', $stripe_settings);


	//update data in menus table
	$menu_data = array( 'route_name' => 'manage_class');
	$CI->db->where('unique_identifier', 'class');
	$CI->db->update('menus', $menu_data);

	//update data in settings table
	$settings_data = array( 'version' => '7.1' );
	$CI->db->update('settings', $settings_data);
?>
